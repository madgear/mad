document.addEventListener('DOMContentLoaded', () => {
    // Functions to open and close a modal
    function openModal($el) {
      $el.classList.add('is-active');
    }
  
    function closeModal($el) {
      $el.classList.remove('is-active');
    }
  
    function closeAllModals() {
      (document.querySelectorAll('.modal') || []).forEach(($modal) => {
        closeModal($modal);
      });
    }
  
    // Add a click event on buttons to open a specific modal
    (document.querySelectorAll('.js-modal-trigger') || []).forEach(($trigger) => {
      const modal = $trigger.dataset.target;
      const $target = document.getElementById(modal);
      console.log($target);
  
      $trigger.addEventListener('click', () => {
        openModal($target);
      });
    });
  
    // Add a click event on various child elements to close the parent modal
    (document.querySelectorAll('.modal-background, .modal-close, .modal-card-head .delete, .modal-card-foot .button') || []).forEach(($close) => {
      const $target = $close.closest('.modal');
  
      $close.addEventListener('click', () => {
        closeModal($target);
      });
    });
  
    // Add a keyboard event to close all modals
    document.addEventListener('keydown', (event) => {
      const e = event || window.event;
  
      if (e.keyCode === 27) { // Escape key
        closeAllModals();
      }
    });
  });
  
g_html=(g_id)=>{return document.getElementById(g_id).innerHTML;}
g_val=(g_id)=>{return document.getElementById(g_id).value;}
s_html=(s_id,response)=>{document.getElementById(s_id).innerHTML=response;}
s_val=(s_id,svalue)=>{document.getElementById(s_id).value=svalue;}
s_class=(s_id,svalue)=>{document.getElementById(s_id).className=svalue;}
s_focus=(s_id)=>{document.getElementById(s_id).focus();}
no_only=(e,x)=>{if(e.keyCode>47 && e.keyCode<58 || e.keyCode==46){if(e.keyCode==46){var txt=x.value;var n=txt.indexOf(".");if(n!=-1){e.preventDefault(true);e.stopPropagation(true);}}}else{e.preventDefault(true);e.stopPropagation(true);}}
s_rand=(len,cs)=>{cs=cs||'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_';var rp='';for(var i=0;i<len;i++){var rs=Math.floor(Math.random()*cs.length);rp+=cs.substring(rs,rs+1);}return rp;}
p_load=(page,divid,cid,purl)=>{$.ajax({url:purl+"/"+page+"/"+cid+"/"+r_rand(13),success:function(r){var s=r;document.getElementById(divid).innerHTML=s;}});}
