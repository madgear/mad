<?php
namespace php_sys\system;
if (!isset($RELATIVE_PATH)) {
	$RELATIVE_PATH = "";
	$ROOT_RELATIVE_PATH = ".";
}
include_once $RELATIVE_PATH . "includes/mad_cfg.php";
include_once $RELATIVE_PATH . "includes/mad_conn.php";
if (file_exists($RELATIVE_PATH . "vendor/autoload.php"))
	require $RELATIVE_PATH . "vendor/autoload.php";	
else	
	die("Please Update Composer!");
	spl_autoload_register(function($class) {
	global $RELATIVE_PATH;
	$file = "";
	$classpath = "includes/";
	$prefix = SABONG_PROJECT;
	$len = strlen($prefix);
	if (strncmp($class, $prefix, $len) === 0) {
		$file = substr($class, $len) . ".php";
	} else { 
		$file = $class . ".php"; 	}
	$file = $classpath . $file;
	if ($file <> "" && file_exists($RELATIVE_PATH . $file))
		include_once $RELATIVE_PATH . $file;
});
	include_once $RELATIVE_PATH . "includes/mad_func.php";
?>
